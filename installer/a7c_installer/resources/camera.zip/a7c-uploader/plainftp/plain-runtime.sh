#!/bin/ash
# ILCE-7C 2.00 only. All runtime files live on checked tmpfs.
# NAS gives a plan, but source names/limits and native completion are checked here.
B=/bin/busybox
P=/setting/a7c-uploader
D=/setting/a7c-uploader/ram
trap '' HUP
STOP=0
trap 'STOP=1' TERM INT
log() {
 local log_clock
 LOG_COUNT=$((${LOG_COUNT:-0}+1))
 # At most 15 bounded messages beyond the previous limit, checked on first use.
 if [ "$((LOG_COUNT%16))" = 1 ] && [ -f "$D/events.log" ] && [ "$($B wc -c < "$D/events.log")" -gt 32768 ]; then $B mv "$D/events.log" "$D/events.previous.log"; fi
 IFS= read -r log_clock < /proc/uptime || log_clock=unknown
 printf '%s %s\n' "$1" "$log_clock" >> "$D/events.log"
}
uptime_seconds() {
 local uptime_unused
 IFS=' ' read -r NOW uptime_unused < /proc/uptime || return 1
 NOW=${NOW%%.*}
 case "$NOW" in ''|*[!0-9]*) return 1;; esac
 [ "${#NOW}" -le 10 ]
}
empty_rec() {
 EMPTY_REC=$($B sed 's/\r//g; /^$/d; /^MPR Debug RecInfo$/d' "$1") || return 1
 [ "$EMPTY_REC" = '[MprMcmd][RecInfo] =====
MON>' ]
}
full_state_idle() {
 # Exact validated suffix. Use only applets present in camera BusyBox (no awk).
 FULL_EXPECTED='MprIf Instance : active
+- Callback() : active
l + owner : active
+- RecParameter
l
+- Status : STATE
+-StillPlayer : none
+-MoviePlayer : none
+-IndexPlayer : none
+-AudioPlayer : none
+-StillRecorder : none
+-MovieRecorder : RECORDER
+-Finalizer : none
+-DubMgr : none
Command Status : Ready
+- Preload Param
+ m_preloadState : 0
+ mp_reservedCmdQueForPreload
+ Count : 0
+ m_execReservedCmdForPreload : 0x40000000
+ mb_existMMgrPreloadSuspendReq : 0
+ mb_prohibitPreload : 0
+ mb_existNewRequestOfPreload : 0
+ m_latestPreloadResult : 0x00000000
+ mb_needWaitAlmForPreloadRestart: 0
+ mb_waitingForAlarm : 0
+ mb_alarmAvailable : 1
+ m_waitTime : 500[ms]
MON>'
 FULL_NORMAL=$($B sed 's/\r//g; s/[[:blank:]][[:blank:]]*/ /g; s/^ //; s/ $//; /^$/d; s/active (at 0x[0-9A-Fa-f][0-9A-Fa-f]*)/active/g' "$1") || return 1
 [ "$(printf '%s\n' "$FULL_NORMAL" | $B grep -c -x '= = = = = MprIf Debug Information = = = = =')" = 1 ] || return 1
 [ "$(printf '%s\n' "$FULL_NORMAL" | $B grep -c -x 'l ProductName : ILCE-7C')" = 1 ] || return 1
 if printf '%s\n' "$FULL_NORMAL" | $B grep -E '(ILLEGAL|FAILURE|ERROR) : true|OVERFLOW|\[ERR\]|\[ERROR\]|Failed to|Illegal ' > /dev/null; then return 1; fi
 FULL_BODY=$(printf '%s\n' "$FULL_NORMAL" | $B sed -n '/^MprIf Instance :/,$p') || return 1
 if printf '%s\n' "$FULL_BODY" | $B grep -q -x '+- Status : STAT_IDLE'; then
  printf '%s\n' "$FULL_BODY" | $B grep -q -x '+-MovieRecorder : none' || return 1
 elif printf '%s\n' "$FULL_BODY" | $B grep -q -x '+- Status : STAT_MREC_STBY'; then
  printf '%s\n' "$FULL_BODY" | $B grep -q -x '+-MovieRecorder : active' || return 1
 else return 1; fi
 FULL_BODY=$(printf '%s\n' "$FULL_BODY" | $B sed 's/^+- Status : STAT_IDLE$/+- Status : STATE/; s/^+- Status : STAT_MREC_STBY$/+- Status : STATE/; s/^+-MovieRecorder : none$/+-MovieRecorder : RECORDER/; s/^+-MovieRecorder : active$/+-MovieRecorder : RECORDER/') || return 1
 [ "$FULL_BODY" = "$FULL_EXPECTED" ]
}
recording_idle() {
 FULL_STATE_USED=0
 $D/monitor recording > "$D/rec" 2> "$D/query.err" || return 1
 if [ "$($B grep -c 'contentType:Movie(XAVC), RecCnt1:0, RecCnt2:0, RecStatus:REC_STATE_STANDBY' "$D/rec")" = 2 ]; then return 0; fi
 empty_rec "$D/rec" || return 2
 [ -x "$D/monitor" ] || return 2
 $D/monitor full-info > "$D/full-state.txt" 2> "$D/query.err" || return 1
 full_state_idle "$D/full-state.txt" || return 2
 # Do not use a fallback across recorder initialization or state transitions.
 $D/monitor recording > "$D/rec-recheck" 2> "$D/query.err" || return 1
 empty_rec "$D/rec-recheck" || return 2
 FULL_STATE_USED=1
}
report() {
 REPORT_STAGE=drive
 $D/monitor drive > "$D/drive" 2> "$D/query.err" || return 1
 LETTER=$($B sed -n "s/\r//g; s/^driveLetter = '\([A-Z]\)'$/\1/p" "$D/drive" | $B tail -1)
 case "$LETTER" in [A-Z]) ;; *) return 1;; esac
 REPORT_STAGE=recording
 recording_idle || return $?
 REPORT_STAGE=directory
 $D/monitor dir "$LETTER" > "$D/dir" 2> "$D/query.err" || return 1
 REPORT_STAGE=file_status
 $D/monitor info > "$D/info" 2> "$D/query.err" || return 1
 { echo A7C_RESIDENT_V1; echo "BOOT=$BOOT"; $B cat "$D/drive" "$D/rec";
   if [ "$FULL_STATE_USED" = 1 ]; then
    echo A7C_FULL_STATE_BEGIN; $B cat "$D/full-state.txt"; echo A7C_FULL_STATE_END
    echo A7C_REC_RECHECK_BEGIN; $B cat "$D/rec-recheck"; echo A7C_REC_RECHECK_END
   fi
   $B cat "$D/dir" "$D/info"; echo A7C_STATUS_END; } > "$D/status"
 [ "$($B wc -c < "$D/status")" -le 262144 ]
}
wait_child() {
 # A trapped TERM must not make wait look like successful native completion.
 wait "$1"; CHILD_RC=$?
 while kill -0 "$1" 2>/dev/null; do wait "$1"; CHILD_RC=$?; done
}
scan_hold_stop() {
 [ -n "$SCAN_HOLD" ] || return 0
 : > "$D/lease.done"
 CHILD_RC=1; wait_child "$SCAN_HOLD"; SCAN_HOLD=
 [ "$CHILD_RC" = 0 ] && $B grep -qx 'PROBE_DONE set=0 clear=0 guardian_status=0' "$D/scan-lease.log" || return 90
 $B rm -f "$D/lease.ready" "$D/lease.done"
 log 'SCAN_HOLD_RELEASED'
}
scan_hold_start() {
 # One bounded lease per worker startup, only for the first stability window.
 # Release and reap before an upload lease reuses these handshake files.
 $B rm -f "$D/lease.done" "$D/lease.ready"
 $D/lease --upload-lease 90 > "$D/scan-lease.log" 2>&1 & SCAN_HOLD=$!
 n=0
 while [ ! -f "$D/lease.ready" ] && [ "$n" -lt 8 ] && kill -0 "$SCAN_HOLD" 2>/dev/null; do $B sleep 1; n=$((n+1)); done
 if [ ! -f "$D/lease.ready" ]; then scan_hold_stop; return 90; fi
 log 'SCAN_HOLD_STARTED limit=90'
}
cleanup_completed_fifos() {
 # Called only after waiting for both relay and network children. Preserve
 # readers/FIFOs when native completion or guardian shutdown is uncertain.
 case "$copy_rc" in 0|73|76) ;; *) return 1;; esac
 [ -f "$D/copy.done" ] && [ -f "$D/guard.done" ] || return 1
 $B grep -qx 'normal\|recovered' "$D/guard.done" || return 1
 $B rm -f "$D/source.fifo" "$D/network.fifo"
}
